import 'package:flutter/material.dart';
import 'package:zomato_api/BLoc/bloc_provider.dart';
import 'package:zomato_api/BLoc/favorite_bloc.dart';
import 'package:zomato_api/BLoc/location_bloc.dart';
import 'package:zomato_api/UI/main_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider<LocationBloc>(
      bloc: LocationBloc(),
      child: BlocProvider<FavoriteBloc>(
        bloc: FavoriteBloc(),
        child: MaterialApp(
          title: 'Zomato',
          theme: ThemeData(
            primarySwatch: Colors.red,
          ),
          home: MainScreen(),
        ),
      ),
    );
  }
}
